/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Temporizador;

import java.util.EventObject;

/**
 *
 * @author APAR
 */
public class FinCuentaAtrasEvent extends EventObject{    
    public FinCuentaAtrasEvent(Object source) {
        super(source);
    }  
}
